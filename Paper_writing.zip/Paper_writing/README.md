All the stuructures are in this web:
[README](https://hackmd.io/s/rk77MwrH7)

And the overleaf web:
[Overleaf edit texts web](https://www.overleaf.com/18372989jfcdfjnqtvfw)




